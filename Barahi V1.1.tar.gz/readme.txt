About the Theme and how to use it?

Name: barahi
Author: Yogesh Lamichhane (visit https://www.yogeshlamichhane.com.np for more)
Version: 1.1
Comment=A dark gtk+ theme for linux.
Encoding=UTF-8

How to use it?
You can see the barahi folder along with this readme.txt file. You simply copy the barahi folder and paste it in the theme folder located in your current user’s home directory.
Detailed Steps:
1. open your current user's home directory ie the path is /home/(your username). In my case it is /home/yogesh
2. Now you should see the .themes folder there. If not enable hidden files by pressing "Ctrl + h". If you still can't find .themes folder create it yourself.
3. paste the barahi folder you copied earlier into the .themes folder.
4. Now go to your system settings >> appearence >> style. There you should see barahi just click it and you're done.
In some cases you should also change it in settings >> window manager. There also you should see barahi just click it and you're done. (this step is not available for all and not compulsory to all.)

if you have any queries regarding the theme or anything mail me at: yogeshlmc3@gmail.com
